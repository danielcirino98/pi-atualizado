<div id="novidades" style="display: flex;">
   
            <span>
              <ul>
                <li><h1 style="color: white; width: 15%; margin: auto; padding: auto;" >Segunda Aba!</h1></li>
                <li><a style="margin: auto; width: 15%; margin: auto; padding: 8px;"  href="erro.html" title="Atualizações recentes">Atualizações recentes</a></li>
                <li><a style="margin: auto; width: 15%; margin: auto; padding: 8px;"  href="erro.html" title="Atualizações em adamento">Em andamento</a></li>
              </ul>
            </span>
  
    <span>
              <ul>
                <li><h1 style="color: white; width: 15%; margin: auto; padding: auto;">Notícias</h1></li>
                <li><a style="margin: auto; width: 15%; margin: auto; padding: 8px;" href="erro.html" title="Notícia oficial">Notícia oficial</a></li>
                <li><a style="margin: auto; width: 15%; margin: auto; padding: 8px;"  href="erro.html" title="Comunidade">Comunidade</a></li>
              </ul>
            </span>   
            <span>
              <ul>
                <li><h1 style="color: white; width: 15%; margin: auto; padding: auto;">Equipe</h1></li>
                <li><a style="margin: auto; width: 15%; margin: auto; padding: 8px;" href="erro.html" title="Descomplicaif">DescomplicaIF</a></li>
               <!-- <li><a style="margin: auto; width: 15%; margin: auto; padding: auto;">Atualizações útimas atualizações</a></li>-->
              </ul>
            </span>   





      </div>