-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25/07/2024 às 16:45
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `descoif`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `perfil`
--

CREATE TABLE `perfil` (
  `avatar` varbinary(220) NOT NULL,
  `idade` datetime(6) NOT NULL,
  `cidade` varchar(220) NOT NULL,
  `bairro` varchar(220) NOT NULL,
  `cep` int(220) NOT NULL,
  `celular` int(220) NOT NULL,
  `cpf` int(12) DEFAULT NULL,
  `nick` varchar(220) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `perfil`
--

INSERT INTO `perfil` (`avatar`, `idade`, `cidade`, `bairro`, `cep`, `celular`, `cpf`, `nick`) VALUES
('', '2024-06-18 00:00:00.000000','0', 'santa cruz', 'paraiso', 59200000, 98047260, 2147483647, 'admim'),


-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(220) NOT NULL,
  `nome` varchar(220) NOT NULL,
  `email` varchar(220) NOT NULL,
  `usuario` varchar(220) NOT NULL,
  `senha` varchar(220) NOT NULL,
  `created` datetime(6) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `avatar` varbinary(220) NOT NULL,
  `idade` int(220) NOT NULL,
  `cidade` varchar(220) NOT NULL,
  `bairro` varchar(220) NOT NULL,
  `cep` varchar(220) NOT NULL,
  `celular` int(12) NOT NULL,
  `cpf` varchar(12) NOT NULL,
  `nick` varchar(64) NOT NULL,
  `keyacess` varchar(220) NOT NULL DEFAULT '2fx729'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `usuario`, `senha`, `created`, `modified`, `avatar`, `idade`, `cidade`, `bairro`, `cep`, `celular`, `cpf`, `nick`, `keyacess`) VALUES
(698, 'José Daniel de Lima Cirino', 'danielcirino2018@gmail.com', 'daniel', '$2y$10$NVhzer24dc9vHztUgOb8/Oo3ORv/iNnPxB/FvGIPenM5LJ6xtNXZK', '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00', '', 1998, 'santa cruz', 'paraiso', '59200000', 98047260, '123456789123', 'SunSpirits', '2fx729'),


--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `perfil`
--
ALTER TABLE `perfil`
  ADD UNIQUE KEY `id` (`nick`) USING BTREE,
  ADD KEY `imagem` (`avatar`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(220) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=704;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
