

 /*function foco(){
   let slide = document.getElementById("slide");
    slide.style.backgroundColor = "purple";
  
    
 }

 function desfoco(){
 
   let fslide = document.getElementById("slide");
   fslide.style.backgroundColor = "#c8d6ca";


 } */

   function btfoco(){

    let clicado = document.getElementById("perfil1");
    clicado.style.transform = ("scale(1.1)");
    clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    clicado.style.backgroundColor = ("purple");
  
  }function btdesfoco(){
  
    let sclicado = document.getElementById("perfil1");
    sclicado.style.transform = ("none");
    sclicado.style.transition = ("none");
    sclicado.style.backgroundColor = ("#c8d6ca");
  
  }
  function alertlogin(){ //Alerta de login
    alert("Você precisar fazer login para ver o conteúdo completo!")
  
  }
  
  function bt2foco(){
  
     let bt2clicado = document.getElementById("perfil2");
     bt2clicado.style.transform = ("scale(1.1)");
     bt2clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
     bt2clicado.style.backgroundColor = ("purple");
   
   
   }
  
   //botão  de popup
  
   
  //fim de botão de poup
   
   function bt2desfoco(){
   
     let sbt2clicado = document.getElementById("perfil2");
     sbt2clicado.style.transform = ("none");
     sbt2clicado.style.transition = ("none");
     sbt2clicado.style.backgroundColor = ("#c8d6ca");
   
   }
  
   function bt3foco(){
  
     let bt3clicado = document.getElementById("perfil3");
     bt3clicado.style.transform = ("scale(1.1)");
     bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
     bt3clicado.style.backgroundColor = ("purple");
   
   
   }
   
   function bt3desfoco(){
   
     let sbt3clicado = document.getElementById("perfil3");
     sbt3clicado.style.transform = ("none");
     sbt3clicado.style.transition = ("none");
     sbt3clicado.style.backgroundColor = ("#c8d6ca");
   
   }

   function bt4foco(){
  
    let bt3clicado = document.getElementById("perfil4");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt4desfoco(){
  
    let sbt3clicado = document.getElementById("perfil4");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }

  function bt5foco(){
  
    let bt3clicado = document.getElementById("perfil5");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt5desfoco(){
  
    let sbt3clicado = document.getElementById("perfil5");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }

  function bt6foco(){
  
    let bt3clicado = document.getElementById("perfil6");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt6desfoco(){
  
    let sbt3clicado = document.getElementById("perfil6");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }

  function bt7foco(){
  
    let bt3clicado = document.getElementById("perfil7");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt7desfoco(){
  
    let sbt3clicado = document.getElementById("perfil7");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }

  function bt8foco(){
  
    let bt3clicado = document.getElementById("perfil8");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt8desfoco(){
  
    let sbt3clicado = document.getElementById("perfil8");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }
  

  function bt9foco(){
  
    let bt3clicado = document.getElementById("perfil9");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt9desfoco(){
  
    let sbt3clicado = document.getElementById("perfil9");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }

  function bt10foco(){
  
    let bt3clicado = document.getElementById("perfil10");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt10desfoco(){
  
    let sbt3clicado = document.getElementById("perfil10");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }

  function bt11foco(){
  
    let bt3clicado = document.getElementById("perfil11");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt11desfoco(){
  
    let sbt3clicado = document.getElementById("perfil11");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }

  function bt12foco(){
  
    let bt3clicado = document.getElementById("perfil12");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt12desfoco(){
  
    let sbt3clicado = document.getElementById("perfil12");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }

  function bt13foco(){
  
    let bt3clicado = document.getElementById("perfil13");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }

  function bt13desfoco(){

    let sbt3clicado = document.getElementById("perfil13");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  
  }

  function bt14foco(){
  
    let bt3clicado = document.getElementById("perfil14");
    bt3clicado.style.transform = ("scale(1.1)");
    bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
    bt3clicado.style.backgroundColor = ("purple");
  
  
  }
  
  function bt14desfoco(){
  
    let sbt3clicado = document.getElementById("perfil14");
    sbt3clicado.style.transform = ("none");
    sbt3clicado.style.transition = ("none");
    sbt3clicado.style.backgroundColor = ("#c8d6ca");
  
  }
  

   function sms(){
  
    alert("Você está sendo redirecionado(a) para uma página externa!");
  
   }
  
   function smsperfil(){
  
    alert("Ao confirmar você estará voltando ao topo da página!");
  
   }
  
  
   function toggleMode(){
    const body = document.body;
    body.classList.toggle("dark-mode");
  
   }
  
  function toggleMode(){
    const body = document.body;
    body.classList.toggle("dark-mode");
    body.classList.toggle("light");
  
  }
  
  
  function toggleMode(){
    const body = document.body;
    body.classList.toggle("dark-mode");
    body.classList.toggle("light-mode");
  
  
  }
  
  let slideIndex = 1;  /* inicio de slide script */
  showSlides(slideIndex);
  
  function plusSlides(n) {
    showSlides(slideIndex += n);
  }
  
  function currentSlide(n) {
    showSlides(slideIndex = n);
  }
  
  function showSlides(n) {
    let i;
    const slides = document.getElementsByClassName("mySlides");
  
    if (n > slides.length) {
      slideIndex = 1;
    }
  
    if (n < 1) {
      slideIndex = slides.length;
    }
  
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
  
    slides[slideIndex - 1].style.display = "block";
  }
    