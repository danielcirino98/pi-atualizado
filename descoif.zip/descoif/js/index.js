

 /*function foco(){
   let slide = document.getElementById("slide");
    slide.style.backgroundColor = "purple";
  
    
 }

 function desfoco(){
 
   let fslide = document.getElementById("slide");
   fslide.style.backgroundColor = "#c8d6ca";


 } */

 function btfoco(){

  let clicado = document.getElementById("bloco1");
  clicado.style.transform = ("scale(1.1)");
  clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
  clicado.style.backgroundColor = ("purple");

}function btdesfoco(){

  let sclicado = document.getElementById("bloco1");
  sclicado.style.transform = ("none");
  sclicado.style.transition = ("none");
  sclicado.style.backgroundColor = ("#c8d6ca");

}
function alertlogin(){ //Alerta de login
  alert("Você precisar fazer login para ver o conteúdo completo!")

}

function bt2foco(){

   let bt2clicado = document.getElementById("bloco2");
   bt2clicado.style.transform = ("scale(1.1)");
   bt2clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
   bt2clicado.style.backgroundColor = ("purple");
 
 
 }

 //botão  de popup

 
//fim de botão de poup
 
 function bt2desfoco(){
 
   let sbt2clicado = document.getElementById("bloco2");
   sbt2clicado.style.transform = ("none");
   sbt2clicado.style.transition = ("none");
   sbt2clicado.style.backgroundColor = ("#c8d6ca");
 
 }

 function bt3foco(){

   let bt3clicado = document.getElementById("bloco3");
   bt3clicado.style.transform = ("scale(1.1)");
   bt3clicado.style.transition = ("background-color 0.5s ease, color 0.5s ease, transform 0.5s ease");
   bt3clicado.style.backgroundColor = ("purple");
 
 
 }
 
 function bt3desfoco(){
 
   let sbt3clicado = document.getElementById("bloco3");
   sbt3clicado.style.transform = ("none");
   sbt3clicado.style.transition = ("none");
   sbt3clicado.style.backgroundColor = ("#c8d6ca");
 
 }

 function sms(){

  alert("Você está sendo redirecionado(a) para uma página externa!");

 }

 function smsperfil(){

  alert("Ao confirmar você estará voltando ao topo da página!");

 }


 function toggleMode(){
  const body = document.body;
  body.classList.toggle("dark-mode");

 }

function toggleMode(){
  const body = document.body;
  body.classList.toggle("dark-mode");
  body.classList.toggle("light");

}


function toggleMode(){
  const body = document.body;
  body.classList.toggle("dark-mode");
  body.classList.toggle("light-mode");


}

let slideIndex = 1;  /* inicio de slide script */
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  const slides = document.getElementsByClassName("mySlides");

  if (n > slides.length) {
    slideIndex = 1;
  }

  if (n < 1) {
    slideIndex = slides.length;
  }

  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }

  slides[slideIndex - 1].style.display = "block";
}
  