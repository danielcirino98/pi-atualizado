



function rastreio(){
      
    ipcode = Geolocation;
    console.log("IP:", ipcode)


}