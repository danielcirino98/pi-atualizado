<?php 

$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "descoif";



//criar a conexão

$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);



