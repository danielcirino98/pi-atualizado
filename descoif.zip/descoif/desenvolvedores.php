<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipe</title>
   <link rel="stylesheet" type="text/css" href="css/perfil.css"> 
</head>
<body>
    <h1>Turma de MSI -  Manutenção e suporte em informática</h1>
    <h2>Projeto integrador -  Descomplica IF 2023</h2>
    <h3>IFRN Campus Santa Cruz</h3>
    
    <section id="gradeperfil">
    <div id="perfil1">
        <img src="imgs/shirlene.jpeg" onmouseover="btfoco()" onmouseleave="btdesfoco()" > <!-- Perfil 0 -->
        <a><b>Maria Shirlene</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais1">Saber mais</button>
        <div id="conteudo"></div></div>
        
        
    </div>
    <div id="perfil2">
        <img src="imgs/cristiane.jpg" onmouseover="bt2foco()" onmouseleave="bt2desfoco()">
        <a><b>Cristiane Bastos</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais2">Saber mais</button>
        <div id="conteudo2"></div></div>

    </div>
    <div id="perfil3">
        <img src="imgs/francinezya.jpg" onmouseover="bt3foco()" onmouseleave="bt3desfoco()">
        <a><b>francinézya Araújo</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais3">Saber mais</button>
        <div id="conteudo3"></div></div>

    </div>
    <div id="perfil4">
        <img src="imgs/gessica.jpeg" onmouseover="bt4foco()" onmouseleave="bt4desfoco()">
        <a><b>Maria Géssica</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais4">Saber mais</button>
        <div id="conteudo4"></div></div>
    
    <div id="perfil5">
        <img src="imgs/josenilda.jpg" onmouseover="bt5foco()" onmouseleave="bt5desfoco()">
        <a><b>Josenilda Medeiros</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais5">Saber mais</button>
        <div id="conteudo5"></div></div>

    <div id="perfil6">
        <img src="imgs/livramento.jpg" onmouseover="bt6foco()" onmouseleave="bt6desfoco()">
        <a><b>Maria do Livramento</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais6">Saber mais</button>
        <div id="conteudo6"></div></div>
    
        <div id="perfil7">
        <img src="imgs/lucas.jpeg" onmouseover="bt7foco()" onmouseleave="bt7desfoco()">
        <a><b>Lucas Venicius</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais7">Saber mais</button>
        <div id="conteudo7"></div></div>

    <div id="perfil8">
        <img src="imgs/neto.png" onmouseover="bt8foco()" onmouseleave="bt8desfoco()">
        <a><b>José Neto</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais8">Saber mais</button>
        <div id="conteudo8"></div></div> 
        
    <div id="perfil9">
        <img src="imgs/patricio.jpg" onmouseover="bt9foco()" onmouseleave="bt9desfoco()">
        <a><b>Patrício Campos</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais9">Saber mais</button>
        <div id="conteudo9"></div></div>
        
    <div id="perfil10">
        <img src="imgs/paulo.png" onmouseover="bt10foco()" onmouseleave="bt10desfoco()">
        <a><b>Paulo Emílio</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais10">Saber mais</button>
        <div id="conteudo10"></div></div> 
        
    <div id="perfil11">
        <img src="imgs/regina.jpg" onmouseover="bt11foco()" onmouseleave="bt11desfoco()">
        <a><b>Damiana Regis</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais11">Saber mais</button>
        <div id="conteudo11"></div></div> 
        
    <div id="perfil12">
        <img src="imgs/robson.jpeg" onmouseover="bt12foco()" onmouseleave="bt12desfoco()">
        <a><b>Robson Souza</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais12">Saber mais</button>
        <div id="conteudo12"></div></div>
        
    <div id="perfil13">
        <img src="imgs/yza.jpg" onmouseover="bt13foco()" onmouseleave="bt13desfoco()">
        <a><b>Isaquiele Assunção</b></a>
        <a>Pesquisador(a)</a>
        <button id="mais13">Saber mais</button>
        <div id="conteudo13"></div></div>

    <div id="perfil14">
        <img src="imgs/daniel.jpg" onmouseover="bt14foco()" onmouseleave="bt14desfoco()">
        <a><b>Daniel Cirino</b></a>
        <a>Desenvolvedor web</a>
        <button id="mais14">Saber mais</button>
        <div id="conteudo14"></div></div>
       
   <!-- <div id="perfil5">

    </div>
    <div id="perfil6">

    </div>
    <div id="perfil7">

    </div> -->
    
            <p>Informações do website</p>
            <p style="font-size: 9px; padding: auto; color: black;">Versão de software: Alfa</p>
            <p style="font-size: 9px; padding: auto; color: black;">Ultima Atualização: 30/07/2024</p>
            <p>Próximas atualizações</p>
            <p style="font-size: 9px; padding: auto; color: black;">Novos tutoriais em pdfs</p>
            <p style="font-size: 9px; padding: auto; color: black;">Novas atualizações informativas</p>
            <h5 style=" margin: auto;">Descomplica IF 2023 - 2024</h5>
            
  
       

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        perfil = ["Shirlene","Cristiane","Francinezia",];
        $("#mais1").click(function(){
        $("#conteudo").load("equipe/divConteudo.php")
      
        
        });
        $("#mais2").click(function(){
        $("#conteudo2").load("equipe/divConteudo2.php")
      
        
        });
        $("#mais3").click(function(){
        $("#conteudo3").load("equipe/divConteudo3.php")
        
        
        });
        $("#mais4").click(function(){
        $("#conteudo4").load("equipe/divConteudo4.php")
        
        });

        $("#mais5").click(function(){
        $("#conteudo5").load("equipe/divConteudo5.php")
        
        });
        $("#mais6").click(function(){
        $("#conteudo6").load("equipe/divConteudo6.php")
        
        });
        $("#mais7").click(function(){
        $("#conteudo7").load("equipe/divConteudo7.php")
        
        });
        $("#mais8").click(function(){
        $("#conteudo8").load("equipe/divConteudo8.php")
        
        });

        $("#mais9").click(function(){
        $("#conteudo9").load("equipe/divConteudo9.php")
        
        });

        $("#mais10").click(function(){
        $("#conteudo10").load("equipe/divConteudo10.php")
        
        });

        $("#mais11").click(function(){
        $("#conteudo11").load("equipe/divConteudo11.php")
        
        });

        $("#mais12").click(function(){
        $("#conteudo12").load("equipe/divConteudo12.php")
        
        });

        $("#mais14").click(function(){
        $("#conteudo14").load("equipe/divConteudo14.php")
        
        });

        $("#mais13").click(function(){
        $("#conteudo13").load("equipe/divConteudo13.php")
        
        });
        $("#curtir").click(function(){  // Curtida com estrelas
        $("#starcontent1").load("star/divconteudostar1.php")
        
        });
    </script>





<script src="js/perfil.js"></script>  
<body>
</html>